package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import javax.swing.JPanel;
import javax.swing.JTextArea;

import javax.swing.border.Border;
import kenken.Board;
import kenken.Cell;
import kenken.Operation;

final class KenKenGrid extends JPanel {

    private static final Font FONT = new Font("Verdana",
            Font.CENTER_BASELINE,
            25);

    private JTextArea[][] grid;

    private final int dimension;
    private JPanel gridPanel;
    private JPanel buttonPanel;
    private JButton solveButton;
    private JButton clearButton;
    private JPanel[][] minisquarePanels;
    public final Board gameBoard;

    KenKenGrid(Board Savedgame) {
        this.dimension = Savedgame.size;
        this.gameBoard = Savedgame;
        setup();
    }

    KenKenGrid(int dimension, int pProb1, int pProb2, int pProb4, int pProbSum, int pProbSub, int pProbDiv, int pProbMult, int pProbMod) {

        this.dimension = dimension;
        this.gameBoard = new Board(dimension, pProb1, pProb2, pProb4, pProbSum, pProbSub, pProbDiv, pProbMult, pProbMod);
        setup();

    }

    public void setup() {
        this.grid = new JTextArea[dimension][dimension];
        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                JTextArea field = new JTextArea();
                grid[y][x] = field;
            }
        }

        this.gridPanel = new JPanel();
        this.buttonPanel = new JPanel();

        Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
        Dimension fieldDimension = new Dimension(40, 40);

        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                JTextArea field = grid[y][x];
                field.setBorder(border);
                field.setFont(FONT);
                field.setPreferredSize(fieldDimension);

            }
        }

        this.gridPanel.setLayout(new GridLayout(dimension,
                dimension));

        this.minisquarePanels = new JPanel[dimension][dimension];

        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                JPanel panel = new JPanel();
                panel.setLayout(new GridLayout(1, 1));
                minisquarePanels[y][x] = panel;
                gridPanel.add(panel);
            }
        }

        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                minisquarePanels[y][x].add(grid[y][x]);
            }
        }

        this.gridPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK,
                2));
        this.clearButton = new JButton("Clear");
        this.solveButton = new JButton("Solve");

        this.buttonPanel.setLayout(new BorderLayout());
        this.buttonPanel.add(clearButton, BorderLayout.WEST);
        this.buttonPanel.add(solveButton, BorderLayout.EAST);

        this.setLayout(new BorderLayout());
        this.add(gridPanel, BorderLayout.NORTH);
        this.add(buttonPanel, BorderLayout.SOUTH);
        desplegarSinSolucion();

        clearButton.addActionListener((ActionEvent e) -> {
            desplegarSinSolucion();
        });
        solveButton.addActionListener((ActionEvent e) -> {
            desplegarConSolucion();
        });
    }

    private void solucion(){
        
    }
    
    private boolean backtracking(int indice){
        while (indice < gameBoard.operations.size()){
            ArrayList<ArrayList<Integer>> possibleSolutions = possibleSolution(gameBoard.operations.get(indice));
            if(possibleSolutions.size() > 0){
                if(backtracking(indice++)){
                    return true;
                }
            }
            else{
                return false;
            }
        }
        return true;
    }
    private static ArrayList<ArrayList<Integer>> possibleSumSubset(int subsetSize, float result, ArrayList<Integer> inputNumbers, ArrayList<Integer> partial, ArrayList<ArrayList<Integer>> solutions){
        int s = 0;
        for(int x: partial){
            s += x;
        }
        if(s == result && partial.size() == subsetSize){
            solutions.add(partial);
   
        }
        
        if (s > result){
            return null;
        }
        for(int i = 0; i < inputNumbers.size(); i++){
            ArrayList<Integer> remaining = new ArrayList<>();
            int n = inputNumbers.get(i);
            for(int j = 1 + i; j < inputNumbers.size(); j++){
                remaining.add(inputNumbers.get(j));
            }
            ArrayList<Integer> partial_rec = new ArrayList<>(partial);
            partial_rec.add(n);
            possibleSumSubset(subsetSize, result, remaining, partial_rec,solutions);
        }
        return solutions;
    } 
    private ArrayList<ArrayList<Integer>> possibleSolution(Operation op){
        int y;
        int x;
        Set<Integer> setX;
        Set<Integer> setY;
        ArrayList<ArrayList<Integer>> solutions = new ArrayList<ArrayList<Integer>>();
        Random rand = new Random();
        ArrayList<Integer> possibleNum = new ArrayList<>();
       
            for(Cell cell : op.cells){
                x = cell.posX;
                y = cell.posY;
                setX = new HashSet<>(gameBoard.possibleNumColumns.get(x));
                setY = new HashSet<>(gameBoard.possibleNumRows.get(y));
                setX.retainAll(setY);
                Integer[] partialPossible = setX.toArray(new Integer[setX.size()]);
                possibleNum.addAll(Arrays.asList(partialPossible));

            }
         if(op.operationType.equals(Operation.OperationType.SUM)){
         solutions = possibleSumSubset(op.cellAmount, op.operationResult, possibleNum, new ArrayList<Integer>(), new ArrayList<ArrayList<Integer>>()); 

        }
        
        return solutions;
    }
    
    private void desplegarConSolucion() {
        gameBoard.setCellsToZero();
        gameBoard.initPossibleNumbers();
        if (backtracking(0)){
            
        int numb;
        int k;
        int j;
        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                numb = gameBoard.cells[y][x].number;
                if (numb < 0) {
                    grid[y][x].setText("" + numb);
                } else {
                    grid[y][x].setText(" " + numb);
                }
                Color bgColor = Color.decode(Board.indexcolors[gameBoard.cells[y][x].operationId % 128]);
                grid[y][x].setBackground(bgColor);
                if (bgColor.getRed() * 0.299 + bgColor.getGreen() * 0.587 + bgColor.getBlue() * 0.114 > 186) {
                    grid[y][x].setForeground(Color.black);
                } else {
                    grid[y][x].setForeground(Color.white);
                }
            }
        }
        for (Operation op : gameBoard.operations) {
            k = op.cells.get(0).posX;
            j = op.cells.get(0).posY;
            grid[j][k].setFont(new Font("Verdana",
                    Font.CENTER_BASELINE,
                    10));
            grid[j][k].setText(op.toStringFirstCell());
            Color bgColor = Color.decode(Board.indexcolors[op.operationId % 128]);
            grid[j][k].setBackground(bgColor);
            if (bgColor.getRed() * 0.299 + bgColor.getGreen() * 0.587 + bgColor.getBlue() * 0.114 > 186) {
                grid[j][k].setForeground(Color.black);
            } else {
                grid[j][k].setForeground(Color.white);
            }
        }
        }
        else{
            JOptionPane.showMessageDialog( buttonPanel, "No se pudo resolver el KenKen","Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void desplegarSinSolucion() {
        int numb;
        int k;
        int j;
        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                numb = gameBoard.cells[y][x].number;

                Color bgColor = Color.decode(Board.indexcolors[gameBoard.cells[y][x].operationId % 128]);
                grid[y][x].setText("");
                grid[y][x].setBackground(bgColor);
                if (bgColor.getRed() * 0.299 + bgColor.getGreen() * 0.587 + bgColor.getBlue() * 0.114 > 186) {
                    grid[y][x].setForeground(Color.black);
                } else {
                    grid[y][x].setForeground(Color.white);
                }
            }
        }
        for (Operation op : gameBoard.operations) {
            k = op.cells.get(0).posX;
            j = op.cells.get(0).posY;
            grid[j][k].setFont(new Font("Verdana",
                    Font.CENTER_BASELINE,
                    10));
            grid[j][k].setText(op.toString());
            Color bgColor = Color.decode(Board.indexcolors[op.operationId % 128]);
            grid[j][k].setBackground(bgColor);
            if (bgColor.getRed() * 0.299 + bgColor.getGreen() * 0.587 + bgColor.getBlue() * 0.114 > 186) {
                grid[j][k].setForeground(Color.black);
            } else {
                grid[j][k].setForeground(Color.white);
            }
        }
    }
    /*
    public static void main(String[] args){
        ArrayList<Integer> possibleNumbers = new ArrayList<>();
        possibleNumbers.add(1);
        possibleNumbers.add(2);
        possibleNumbers.add(3);
        possibleNumbers.add(4);
        possibleNumbers.add(5);
        possibleNumbers.add(0);
        ArrayList<ArrayList<Integer>> results = possibleSumSubset(2, 5, possibleNumbers,new ArrayList<Integer>(), new ArrayList<ArrayList<Integer>>());
        results.remove(0);
    }
    */
}
